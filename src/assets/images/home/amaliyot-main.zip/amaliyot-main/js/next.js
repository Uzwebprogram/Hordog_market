let buttonsas = document.querySelector(".slick-prev")
buttonsas.textContent = "<"
let buttonsaser = document.querySelector(".slick-next")
buttonsaser.textContent = ">"